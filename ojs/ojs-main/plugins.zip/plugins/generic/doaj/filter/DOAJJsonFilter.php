<?php

/**
 * @file plugins/generic/doaj/filter/DOAJJsonFilter.php
 *
 * Copyright (c) 2014-2025 Simon Fraser University
 * Copyright (c) 2000-2025 John Willinsky
 * Distributed under the GNU GPL v3. For full terms see the file docs/COPYING.
 *
 * @class DOAJJsonFilter
 *
 * @ingroup plugins_generic_doaj
 *
 * @brief Class that converts an Article to a DOAJ JSON string.
 */

namespace APP\plugins\generic\doaj\filter;

use APP\core\Application;
use APP\facades\Repo;
use APP\plugins\generic\doaj\DOAJExportDeployment;
use APP\plugins\generic\doaj\DOAJExportPlugin;
use APP\publication\Publication;
use APP\submission\Submission;
use PKP\context\Context;
use PKP\core\PKPString;
use PKP\plugins\importexport\PKPImportExportFilter;

class DOAJJsonFilter extends PKPImportExportFilter
{
    /**
     * Constructor
     *
     * @param \PKP\filter\FilterGroup $filterGroup
     */
    public function __construct($filterGroup)
    {
        $this->setDisplayName('DOAJ JSON export');
        parent::__construct($filterGroup);
    }

    //
    // Implement template methods from Filter
    //
    /**
     * @see Filter::process()
     *
     * @param Submission|Publication $pubObject
     *
     * @return string JSON
     */
    public function &process(&$pubObject)
    {
        /** @var DOAJExportDeployment */
        $deployment = $this->getDeployment();
        $context = $deployment->getContext();
        /** @var DOAJExportPlugin */
        $plugin = $deployment->getPlugin();
        $cache = $plugin->getCache();

        // Create the JSON string
        // Article JSON example bibJson https://github.com/DOAJ/harvester/blob/9b59fddf2d01f7c918429d33b63ca0f1a6d3d0d0/service/tests/fixtures/article.py
        // S. also https://doaj.github.io/doaj-docs/master/data_models/IncomingAPIArticle

        if (is_a($pubObject, Submission::class)) {
            $publication = $pubObject->getCurrentPublication();
            /** @var Submission $article */
            $article = $pubObject;
            if (!$cache->isCached('articles', $article->getId())) {
                $cache->add($article, null);
            }
        } else {
            /** @var Publication $publication */
            $publication = $pubObject;
            if ($cache->isCached('articles', $publication->getData('submissionId'))) {
                /** @var Submission $article */
                $article = $cache->get('articles', $publication->getData('submissionId'));
            } else {
                $article = Repo::submission()->get($publication->getData('submissionId'));
                if ($article) {
                    $cache->add($article, null);
                }
            }
        }
        $publicationLocale = $publication->getData('locale');

        $issueId = $publication->getData('issueId');
        $issue = null;
        if ($issueId) {
            if ($cache->isCached('issues', $issueId)) {
                $issue = $cache->get('issues', $issueId);
            } else {
                $issue = Repo::issue()->get($issueId);
                if ($issue) {
                    $cache->add($issue, null);
                }
            }
        }

        $doajArticle = [];
        $doajArticle['bibjson']['journal'] = [];
        // Publisher name (i.e. institution name)
        $publisher = $context->getData('publisherInstitution');
        if (!empty($publisher)) {
            $doajArticle['bibjson']['journal']['publisher'] = $publisher;
        }
        // To-Do: license ???
        // Journal's title (M)
        $journalTitle = $context->getName($context->getPrimaryLocale());
        $doajArticle['bibjson']['journal']['title'] = $journalTitle;
        // Identification Numbers
        $issns = [];
        $pissn = $context->getData('printIssn');
        if (!empty($pissn)) {
            $issns[] = $pissn;
        }
        $eissn = $context->getData('onlineIssn');
        if (!empty($eissn)) {
            $issns[] = $eissn;
        }
        if (!empty($issns)) {
            $doajArticle['bibjson']['journal']['issns'] = $issns;
        }
        // Volume, Number
        $volume = $issue?->getVolume();
        if (!empty($volume)) {
            $doajArticle['bibjson']['journal']['volume'] = $volume;
        }
        $issueNumber = $issue?->getNumber();
        if (!empty($issueNumber)) {
            $doajArticle['bibjson']['journal']['number'] = $issueNumber;
        }

        // Article title
        $doajArticle['bibjson']['title'] = $publication?->getLocalizedTitle($publicationLocale) ?? '';
        // Identifiers
        $doajArticle['bibjson']['identifier'] = [];
        // DOI
        $doi = $publication->getDoi();
        if (!empty($doi)) {
            $doajArticle['bibjson']['identifier'][] = ['type' => 'doi', 'id' => $doi];
        }
        // Print and online ISSN
        if (!empty($pissn)) {
            $doajArticle['bibjson']['identifier'][] = ['type' => 'pissn', 'id' => $pissn];
        }
        if (!empty($eissn)) {
            $doajArticle['bibjson']['identifier'][] = ['type' => 'eissn', 'id' => $eissn];
        }
        // Year and month from article's publication date
        if ($publication->getData('datePublished')) {
            $publicationDate = $this->formatDate($publication->getData('datePublished'));
        } elseif ($issue?->getDatePublished()) {
            $publicationDate = $this->formatDate($issue->getDatePublished());
        }
        $yearMonth = explode('-', $publicationDate);
        $doajArticle['bibjson']['year'] = $yearMonth[0];
        $doajArticle['bibjson']['month'] = $yearMonth[1];
        /** --- FirstPage / LastPage (from PubMed plugin)---
         * there is some ambiguity for online journals as to what
         * "page numbers" are; for example, some journals (eg. JMIR)
         * use the "e-location ID" as the "page numbers" in PubMed
         */
        $startPage = $publication->getStartingPage();
        $endPage = $publication->getEndingPage();
        if (isset($startPage) && $startPage !== '') {
            $doajArticle['bibjson']['start_page'] = $startPage;
            $doajArticle['bibjson']['end_page'] = $endPage;
        }
        // FullText URL
        $request = Application::get()->getRequest();
        $doajArticle['bibjson']['link'] = [];
        if ($context->getData(Context::SETTING_DOI_VERSIONING)) {
            $doajArticle['bibjson']['link'][] = [
                'url' => $request->getDispatcher()->url($request, Application::ROUTE_PAGE, $context->getPath(), 'article', 'view', [$article->getId(), 'version', $publication->getId()], urlLocaleForPage: ''),
                'type' => 'fulltext',
                'content_type' => 'html'
            ];
        } else {
            $doajArticle['bibjson']['link'][] = [
                'url' => $request->getDispatcher()->url($request, Application::ROUTE_PAGE, $context->getPath(), 'article', 'view', [$article->getId()], urlLocaleForPage: ''),
                'type' => 'fulltext',
                'content_type' => 'html'
            ];
        }
        // Authors: name, affiliation and ORCID
        $articleAuthors = $publication->getData('authors');
        if ($articleAuthors->isNotEmpty()) {
            $doajArticle['bibjson']['author'] = [];

            foreach ($articleAuthors as $articleAuthor) {
                $author = ['name' => $articleAuthor->getFullName(false, false, $publicationLocale)];
                $affiliations = $articleAuthor->getLocalizedAffiliationNamesAsString($publicationLocale);
                if (!empty($affiliations)) {
                    $author['affiliations'] = $affiliations;
                }
                if ($articleAuthor->getData('orcid') && $articleAuthor->getData('orcidIsVerified')) {
                    $author['orcid_id'] = $articleAuthor->getData('orcid');
                }
                $doajArticle['bibjson']['author'][] = $author;
            }
        }

        // Abstract
        $abstract = $publication->getData('abstract', $publicationLocale);
        if (!empty($abstract)) {
            $doajArticle['bibjson']['abstract'] = PKPString::html2text($abstract);
        }

        // Keywords
        $keywords = collect($publication->getData('keywords') ?? [])
            ->map(
                fn (array $items): array => collect($items)
                    ->pluck('name')
                    ->all()
            )
            ->all();

        $allowedNoOfKeywords = array_slice($keywords[$publicationLocale] ?? [], 0, 6);
        if (!empty($keywords[$publicationLocale])) {
            $doajArticle['bibjson']['keywords'] = $allowedNoOfKeywords;
        }

        $json = json_encode($doajArticle);
        return $json;
    }

    /**
     * Format a date by Y-F format.
     *
     * @param string $date
     *
     * @return string
     */
    public function formatDate($date)
    {
        if ($date == '') {
            return null;
        }
        return date('Y-F', strtotime($date));
    }
}
